﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;

namespace cloudtestweb
{
    public partial class WebService : System.Web.UI.Page
    {
        //本範例使用雲元件認證，搭配呼叫GeoWeb的Web Service使用服務，並結合CMap API將結果呈現在地圖上
        //因每次使用GeoWeb服務所需的key都需呼叫雲元件動態取得，因此需前後端的參數傳遞，範例流程如下
        //1. 頁面開啟時需初始化地圖服務，因此呼叫雲元件認證取得key  
        //2. 在前端引用key參數，即完成地圖服務認證，<script language="javascript" type="text/javascript" shttp://showtaiwan-wms-api.hicloud.net.tw/IntegratedMapService/GetAPI.aspx?key=<% = key %>&ver=2"></script>
        //3. 在前端onload會呼叫loadMap，初始化地圖物件
        //4. 當進行關鍵字搜尋，要先呼叫後端雲元件認證取得key
        //5. 成功取得key後，呼叫GeoWeb相對應服務的web service
        //6. 取得回傳結果

        public static string key;
        protected void Page_Load(object sender, EventArgs e)
        {
            key = getToken("18");
            if (key == "")
            {
                ClientScriptManager cs = Page.ClientScript;
                cs.RegisterStartupScript(this.GetType(), "PopupScript", "alert('雲元件管理平台認證異常，請再次確認參數! ');", true);
            }
        }

        [WebMethod]
        public static string getToken(string num)
        {
            string tempkey = "";
            //Response.Write("start AuthMgr test" + "<br/>");
            long sec = cht.ccsdk.proxy.ServiceManager.genTimestamp();//產生timestamp long value
            String str_sec = Convert.ToString(sec);
            String nonce = cht.ccsdk.proxy.ServiceManager.genNonce();//產出nonce
            String isvKey = "n+ABj+1w6e1Ht2A2ziBh0Q==";
            String isvAccount = "367f7deaa1ce47b185a0c91cb6d8f714";
            String serviceID = num;

            //若有需要自行指定porxy info，可用另一個constructor宣告
            cht.ccsdk.proxy.ServiceManager srvMgr = new cht.ccsdk.proxy.ServiceManager("http", "api.hicloud.hinet.net", 80, true);  

            //api user藉由ServiceManager取得token//
            cht.ccsdk.bean.AuthTokenBean tokenBean = srvMgr.requestToken(isvAccount, serviceID, nonce, str_sec, cht.ccsdk.proxy.ServiceManager.genSign(isvKey + nonce + str_sec, "SHA1"));
            if (tokenBean != null)
            {
                tempkey = tokenBean.sign + "^" + tokenBean.token;
            }
            return tempkey;
        }
    }
}