﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace cloudtestweb
{
    public partial class GeoWebSDK : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Label2.Text = "";
            }
        }

        protected void search_btn_Click(object sender, EventArgs e)
        {
            //請至雲創平台>雲元件服務>介接設定取得帳號及密碼
            //本範例以GeoWeb圖徵服務為例，透過GeoWeb提供的SDK直接使用服務，而不需自行進行雲元件認證

            string account = "367f7deaa1ce47b185a0c91cb6d8f714";
            string psw = "n+ABj+1w6e1Ht2A2ziBh0Q==";

            //若有需要自行指定porxy info，可用另一個constructor宣告
            com.cht.emap.webservice.sdk.FeatureService Fservice = new com.cht.emap.webservice.sdk.FeatureService(account, psw, "http", "api.hicloud.hinet.net", 80, true);

            // 宣告圖徵定位服務
            com.cht.emap.webservice.FS.FS_Feature_Result FeatureResult = null;

            //為了顯示回傳資訊使用
            ClientScriptManager cs = Page.ClientScript;

            try
            {
                //依照參數進行圖徵定位
                string keyword = TextBox1.Text;
                FeatureResult = Fservice.SmartRefinedQuery(keyword);
                if (FeatureResult.Information.Code > 0)
                {
                    string showmsg = "回傳結果OK， Return Code = " + FeatureResult.Information.Code + " & Return Msg =  " + FeatureResult.Information.Message + "\\n\\n";
                    string name = FeatureResult.FeatureList[0].SysName;
                    string county = FeatureResult.FeatureList[0].County;
                    string town = FeatureResult.FeatureList[0].Town;
                    showmsg += "第一筆搜尋結果為: " + name + " " + county + town;
                    //cs.RegisterStartupScript(this.GetType(), "PopupScript", "alert('" + showmsg + "');", true);
                    Label2.Text = showmsg;

                }
                else
                    //cs.RegisterStartupScript(this.GetType(), "PopupScript", "alert('沒有回傳結果， Return Code = " + FeatureResult.Information.Code + " & Return Msg =  " + FeatureResult.Information.Message + "');", true);
                    Label2.Text = "沒有回傳結果， Return Code = " + FeatureResult.Information.Code + " & Return Msg =  " + FeatureResult.Information.Message;
            }
            catch (System.ApplicationException ex)
            {
                // 本元件功能異常
                //cs.RegisterStartupScript(this.GetType(), "PopupScript", "alert('本元件功能異常 : " + ex + "');", true);
                Label2.Text = "本元件功能異常 : " + ex.ToString();

            }
            catch (System.SystemException ey)
            {
                // 雲元件管理平台認證異常
                //cs.RegisterStartupScript(this.GetType(), "PopupScript", "alert('雲元件管理平台認證異常 : " + ey + "');", true);
                Label2.Text = "雲元件管理平台認證異常 : " + ey.ToString();
            }
        }
    }
}